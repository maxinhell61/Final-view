









import sys
sys.path.append("app")  # Adjust based on actual structure

from __init__ import app, db
from models import Product

products = [
    # Fruits
    {"name": "Banana", "category": "Fruits", "price": 30, "stock": 100, "unit": "dozen", "description": "Fresh ripe bananas"},
    # {"name": "Apple", "category": "Fruits", "price": 150, "stock": 80, "unit": "kg", "description": "Juicy red apples"},
    # {"name": "Mango", "category": "Fruits", "price": 200, "stock": 60, "unit": "kg", "description": "Seasonal Alphonso mangoes"},
    # {"name": "Grapes", "category": "Fruits", "price": 90, "stock": 70, "unit": "kg", "description": "Green seedless grapes"},
    # {"name": "Papaya", "category": "Fruits", "price": 50, "stock": 40, "unit": "kg", "description": "Fresh papayas rich in enzymes"},
    # {"name": "Orange", "category": "Fruits", "price": 60, "stock": 90, "unit": "kg", "description": "Juicy oranges full of vitamin C"},
    # {"name": "Pineapple", "category": "Fruits", "price": 70, "stock": 50, "unit": "piece", "description": "Tropical sweet pineapples"},
    # {"name": "Watermelon", "category": "Fruits", "price": 40, "stock": 30, "unit": "kg", "description": "Big juicy watermelons"},
    # {"name": "Guava", "category": "Fruits", "price": 55, "stock": 45, "unit": "kg", "description": "Locally grown guavas"},
    # {"name": "Pomegranate", "category": "Fruits", "price": 120, "stock": 60, "unit": "kg", "description": "Sweet red pomegranates"},

    # # Vegetables
    # {"name": "Tomato", "category": "Vegetables", "price": 30, "stock": 100, "unit": "kg", "description": "Fresh red tomatoes"},
    # {"name": "Onion", "category": "Vegetables", "price": 25, "stock": 120, "unit": "kg", "description": "Indian kitchen essential"},
    # {"name": "Potato", "category": "Vegetables", "price": 20, "stock": 150, "unit": "kg", "description": "Staple vegetable"},
    # {"name": "Cabbage", "category": "Vegetables", "price": 35, "stock": 80, "unit": "piece", "description": "Fresh green cabbage"},
    # {"name": "Cauliflower", "category": "Vegetables", "price": 40, "stock": 60, "unit": "piece", "description": "Organic cauliflower heads"},
    # {"name": "Carrot", "category": "Vegetables", "price": 45, "stock": 70, "unit": "kg", "description": "Crunchy red carrots"},
    # {"name": "Brinjal", "category": "Vegetables", "price": 30, "stock": 50, "unit": "kg", "description": "Locally grown brinjals"},
    # {"name": "Bottle Gourd", "category": "Vegetables", "price": 25, "stock": 40, "unit": "piece", "description": "Soft green lauki"},
    # {"name": "Spinach", "category": "Vegetables", "price": 20, "stock": 30, "unit": "bunch", "description": "Fresh leafy spinach"},
    # {"name": "Lady Finger", "category": "Vegetables", "price": 50, "stock": 60, "unit": "kg", "description": "Tender green bhindi"},

    # Dairy
    # {"name": "Milk", "category": "Dairy", "price": 60, "stock": 100, "unit": "litre", "description": "Fresh cow milk"},
    # {"name": "Butter", "category": "Dairy", "price": 200, "stock": 40, "unit": "pack", "description": "Amul salted butter"},
    # {"name": "Cheese", "category": "Dairy", "price": 250, "stock": 30, "unit": "pack", "description": "Processed cheese slices"},
    # {"name": "Curd", "category": "Dairy", "price": 50, "stock": 80, "unit": "litre", "description": "Homemade thick curd"},
    # {"name": "Paneer", "category": "Dairy", "price": 300, "stock": 40, "unit": "kg", "description": "Soft and fresh paneer"},
    # {"name": "Ghee", "category": "Dairy", "price": 600, "stock": 30, "unit": "litre", "description": "Pure desi ghee"},
    # {"name": "Condensed Milk", "category": "Dairy", "price": 150, "stock": 20, "unit": "can", "description": "Sweetened condensed milk"},
    # {"name": "Flavored Yogurt", "category": "Dairy", "price": 80, "stock": 50, "unit": "cup", "description": "Mango-flavored yogurt"},
    # {"name": "Margarine", "category": "Dairy", "price": 180, "stock": 20, "unit": "pack", "description": "Non-dairy butter substitute"},
    # {"name": "Whipping Cream", "category": "Dairy", "price": 350, "stock": 25, "unit": "litre", "description": "For cakes and desserts"},
]

# Insert into database
with app.app_context():
    for item in products:
        product = Product(
            name=item["name"],
            category=item["category"],
            price=item["price"],
            stock=item["stock"],
            unit=item["unit"],
            description=item["description"],
            image_url=None
        )
        db.session.add(product)

    db.session.commit()
    print("✅ Products with descriptions added successfully!")
