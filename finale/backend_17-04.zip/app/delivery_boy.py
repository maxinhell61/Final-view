## Order Model
class Order(db.Model):
    id = db.Column(db.Integer, primary_key=True)
   
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    user = db.relationship('User', foreign_keys=[user_id], backref='orders')
 
    products = db.Column(db.JSON, nullable=False)
    total_price = db.Column(db.Float, nullable=False)
    status = db.Column(db.String(50), default="Pending")
    payment_mode = db.Column(db.String(20))  # "COD" or "Online"
   
    delivery_boy_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=True)
    delivery_boy = db.relationship('User', foreign_keys=[delivery_boy_id], backref='deliveries')
 
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
 
    def to_dict(self):
        return {
            "id": self.id,
            "user_id": self.user_id,
            "products": self.products,
            "total_price": self.total_price,
            "status": self.status,
            "payment_mode": self.payment_mode,
            "delivery_boy_id": self.delivery_boy_id,
            "delivery_boy_name": self.delivery_boy.name if self.delivery_boy else None,
            "created_at": self.created_at.isoformat()
        }

# Delivery Boy Model 
class DeliveryBoy(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), unique=True, nullable=False)
    status = db.Column(db.String(10), default='free')  # 'free' or 'engaged'
    user = db.relationship('User', backref=db.backref('delivery_boy', uselist=False))

    def to_dict(self):
        return {
            "id": self.id,
            "user_id": self.user_id,
            "status": self.status,
            "name": self.user.name,
            "email": self.user.email,
            "phone": self.user.phone,
        }


--------------------------
from flask import Blueprint, request, jsonify
from flask_jwt_extended import jwt_required, get_jwt_identity
from app.models import Order,User
from app import db
 
order_bp = Blueprint("order", __name__, url_prefix="/orders")
# Place Order
@order_bp.route("/place", methods=["POST"])
@jwt_required()
def place_order():
    user_id = get_jwt_identity()
    data = request.get_json()
 
    if not data or "products" not in data or "total_price" not in data or "payment_mode" not in data:
        return jsonify({"error": "Invalid order data"}), 400
 
    delivery_boy_id = data.get("delivery_boy_id")  # optional field
 
    if delivery_boy_id:
        delivery_boy = User.query.get(delivery_boy_id)
        if not delivery_boy or delivery_boy.role != "delivery":
            return jsonify({"error": "Invalid delivery boy ID"}), 400
    else:
        delivery_boy_id = None  # Assign later
 
    new_order = Order(
        user_id=user_id,
        products=data["products"],
        total_price=data["total_price"],
        payment_mode=data["payment_mode"],
        delivery_boy_id=delivery_boy_id
    )
 
    db.session.add(new_order)
    db.session.commit()
 
    return jsonify({"message": "Order placed successfully", "order_id": new_order.id}), 201
 
 
# Assign Delivery Boy to Order (Admin Only)
@order_bp.route("/assign_delivery_boy/<int:order_id>", methods=["PUT"])
@jwt_required()
def assign_delivery_boy(order_id):
    user_id = get_jwt_identity()
    admin = User.query.get(user_id)
 
    if admin.role != "admin":
        return jsonify({"error": "Unauthorized"}), 403
 
    order = Order.query.get(order_id)
    if not order:
        return jsonify({"error": "Order not found"}), 404
 
    data = request.get_json()
    delivery_boy_id = data.get("delivery_boy_id")
 
    if not delivery_boy_id:
        return jsonify({"error": "Delivery boy ID is required"}), 400
 
    delivery_boy = User.query.get(delivery_boy_id)
    if not delivery_boy or delivery_boy.role != "delivery_boy":
        return jsonify({"error": "Invalid delivery boy"}), 400
 
    order.delivery_boy_id = delivery_boy_id
    db.session.commit()
 
    return jsonify({
        "message": f"Delivery boy '{delivery_boy.name}' assigned to order {order.id}",
        "order": order.to_dict()
    }), 200
 
 
 
# Get User Orders
@order_bp.route("/userorder", methods=["GET"])
@jwt_required()
def get_user_orders():
    user_id = get_jwt_identity()
    orders = Order.query.filter_by(user_id=user_id).order_by(Order.created_at.desc()).all()
   
    return jsonify([order.to_dict() for order in orders]), 200
 
 
# Get Order Details
@order_bp.route("/<int:order_id>", methods=["GET"])
@jwt_required()
def get_order_details(order_id):
    user_id = get_jwt_identity()
    order = Order.query.filter_by(id=order_id, user_id=user_id).first()
 
    if not order:
        return jsonify({"error": "Order not found"}), 404
 
    return jsonify(order.to_dict()), 200
 
 
# Cancel Order
@order_bp.route("/cancel/<int:order_id>", methods=["DELETE"])
@jwt_required()
def cancel_order(order_id):
    user_id = get_jwt_identity()
    order = Order.query.filter_by(id=order_id, user_id=user_id).first()
 
    if not order:
        return jsonify({"error": "Order not found"}), 404
 
    if order.status != "Pending":
        return jsonify({"error": "Only pending orders can be canceled"}), 400
 
    order.status = "Canceled"
    db.session.commit()
 
    return jsonify({"message": "Order canceled successfully"}), 200
 
 
# Track Order Status
@order_bp.route("/track/<int:order_id>", methods=["GET"])
@jwt_required()
def track_order_status(order_id):
    user_id = get_jwt_identity()
    order = Order.query.filter_by(id=order_id, user_id=user_id).first()
 
    if not order:
        return jsonify({"error": "Order not found"}), 404
 
    return jsonify({"order_id": order.id, "status": order.status}), 200
 
 
# Return Order
@order_bp.route("/return/<int:order_id>", methods=["POST"])
@jwt_required()
def return_order(order_id):
    user_id = get_jwt_identity()
    order = Order.query.filter_by(id=order_id, user_id=user_id).first()
 
    if not order:
        return jsonify({"error": "Order not found"}), 404
 
    if order.status != "Delivered":
        return jsonify({"error": "Only delivered orders can be returned"}), 400
 
    order.status = "Returned"
    db.session.commit()
 
    return jsonify({"message": "Order returned successfully"}), 200
 
# Get All Orders (Admin Only)
@order_bp.route("/", methods=["GET"])
@jwt_required()
def get_all_orders():
    user_id = get_jwt_identity()
    user = User.query.get(user_id)
 
    if user.role == "admin":  # Admin can see all orders
        orders = Order.query.order_by(Order.created_at.desc()).all()
    else:
        orders = Order.query.filter_by(user_id=user_id).order_by(Order.created_at.desc()).all()
 
    return jsonify([order.to_dict() for order in orders]), 200
 
# Update Order Status (Admin Only)
@order_bp.route("/update_status/<int:order_id>", methods=["PUT"])
@jwt_required()
def update_order_status(order_id):
    user_id = get_jwt_identity()
    user = User.query.get(user_id)
 
    if user.role != "admin":
        return jsonify({"error": "Unauthorized"}), 403  # Only admins can update status
 
    order = Order.query.get(order_id)
 
    if not order:
        return jsonify({"error": "Order not found"}), 404
 
    data = request.get_json()
    new_status = data.get("status")
 
    valid_statuses = ["Pending", "Processing", "Shipped", "Delivered", "Canceled", "Returned"]
 
    if new_status not in valid_statuses:
        return jsonify({"error": "Invalid status"}), 400
 
    order.status = new_status
    db.session.commit()
 
    return jsonify({"message": f"Order status updated to {new_status}"}), 200


---------------------------------------------------------------------------------------------

from flask import Blueprint, request, jsonify
from flask_jwt_extended import jwt_required, get_jwt_identity
from app.models import Order,User,DeliveryBoy,Product
from app import db

delivery_boy_bp = Blueprint("delivery_boy",__name__,url_prefix="/delivery_boy")
# Add Delivery boy 
delivery_boy_bp.route('/api/delivery-boy', methods=['POST'])
def add_delivery_boy():
    data = request.json
    # Create User
    new_user = User(
        name=data['name'],
        email=data['email'],
        phone=data['phone'],
        password=data['password'],
        role="delivery"
    )
    db.session.add(new_user)
    db.session.flush()  # Get new_user.id without committing

    # Create DeliveryBoy
    new_delivery_boy = DeliveryBoy(user_id=new_user.id, status="free")
    db.session.add(new_delivery_boy)
    db.session.commit()

    return jsonify({"message": "Delivery boy added successfully"}), 201

#Update Delivery Boy 
delivery_boy_bp.route('/api/delivery-boy/<int:id>', methods=['PUT'])
def update_delivery_boy(id):
    data = request.json
    delivery_boy = DeliveryBoy.query.get(id)
    if not delivery_boy:
        return jsonify({"error": "Delivery boy not found"}), 404

    user = delivery_boy.user
    user.name = data.get('name', user.name)
    user.phone = data.get('phone', user.phone)
    delivery_boy.status = data.get('status', delivery_boy.status)

    db.session.commit()
    return jsonify({"message": "Delivery boy updated successfully"}), 200
# Delete Delivery Boy
delivery_boy_bp.route('/api/delivery-boy/<int:id>', methods=['DELETE'])
def delete_delivery_boy(id):
    delivery_boy = DeliveryBoy.query.get(id)
    if not delivery_boy:
        return jsonify({"error": "Delivery boy not found"}), 404

    user = delivery_boy.user
    db.session.delete(delivery_boy)
    db.session.delete(user)
    db.session.commit()
    return jsonify({"message": "Delivery boy deleted successfully"}), 200

#List Delivery Boys by Status
delivery_boy_bp.route('/api/delivery-boys', methods=['GET'])
def list_delivery_boys():
    status = request.args.get('status')
    query = DeliveryBoy.query
    if status:
        query = query.filter_by(status=status)
    delivery_boys = query.all()
    return jsonify([db.to_dict() for db in delivery_boys]), 200

#Assign Delivery Boy to Order
delivery_boy_bp.route('/api/orders/<int:order_id>/assign', methods=['PUT'])
def assign_delivery_boy(order_id):
    data = request.json
    delivery_boy_id = data.get('delivery_boy_id')

    order = Order.query.get(order_id)
    delivery_boy = DeliveryBoy.query.get(delivery_boy_id)

    if not order or not delivery_boy:
        return jsonify({"error": "Invalid order or delivery boy"}), 404

    order.delivery_boy_id = delivery_boy_id
    delivery_boy.status = "engaged"
    db.session.commit()
    return jsonify({"message": "Order assigned successfully"}), 200

#Get Total Orders Completed by a Delivery Boy
delivery_boy_bp.route('/api/delivery-boy/<int:id>/orders/count', methods=['GET'])
def get_orders_count(id):
    delivery_boy = DeliveryBoy.query.get(id)
    if not delivery_boy:
        return jsonify({"error": "Delivery boy not found"}), 404

    count = Order.query.filter_by(delivery_boy_id=id, status="Delivered").count()
    return jsonify({
        "delivery_boy_id": id,
        "delivered_orders_count": count
    }), 200


delivery_boy_bp.route('/api/delivery-boy/<int:id>/orders/count', methods=['GET'])
def get_orders_count(id):
    status = request.args.get('status', 'Delivered')
    delivery_boy = DeliveryBoy.query.get(id)
    if not delivery_boy:
        return jsonify({"error": "Delivery boy not found"}), 404

    count = Order.query.filter_by(delivery_boy_id=id, status=status).count()
    return jsonify({
        "delivery_boy_id": id,
        "status": status,
        "orders_count": count
    }), 200

