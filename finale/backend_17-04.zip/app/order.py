from flask import Blueprint, request, jsonify
from flask_jwt_extended import jwt_required, get_jwt_identity
from datetime import datetime
from app import db
from app.models import User, Product, Cart, Order, OrderItems, Address,Inventory

order_bp = Blueprint("order", __name__)




@order_bp.route("/place", methods=["POST"])
@jwt_required()
def place_order():
    user_id = get_jwt_identity()
    data = request.get_json()

    # Check required fields
    if not data or "address_id" not in data or "payment_mode" not in data:
        return jsonify({"error": "Missing address or payment mode"}), 400

    # Normalize payment_mode
    payment_mode = data["payment_mode"].strip().lower()

    # Validate address ownership
    address = Address.query.filter_by(id=data["address_id"], user_id=user_id).first()
    if not address:
        return jsonify({"error": "Invalid or unauthorized address"}), 400

    # Fetch cart items
    cart_items = Cart.query.filter_by(user_id=user_id).all()
    if not cart_items:
        return jsonify({"error": "Cart is empty"}), 400

    total_price = 0
    order_item_objects = []

    # Validate stock and calculate total
    for item in cart_items:
        product = Product.query.get(item.product_id)
        if not product:
            return jsonify({"error": f"Product not found for ID {item.product_id}"}), 404

        if product.stock < item.quantity:
            return jsonify({"error": f"Insufficient stock for '{product.name}'"}), 400

        total_price += product.price * item.quantity
        order_item_objects.append({
            "product_id": product.id,
            "quantity": item.quantity,
            "price": product.price
        })

    # Create order with appropriate status
    new_order = Order(
        user_id=user_id,
        total_price=total_price,
        status="Pending" if payment_mode == "cod" else "Paid",
        created_at=datetime.utcnow()
    )
    db.session.add(new_order)
    db.session.flush()  # Get order.id before creating items

    # Add order items and update inventory
    for item in order_item_objects:
        db.session.add(OrderItems(
            order_id=new_order.id,
            product_id=item["product_id"],
            quantity=item["quantity"],
            price_at_order_time=item["price"]
        ))

        # Deduct from Product stock
        product = Product.query.get(item["product_id"])
        product.stock -= item["quantity"]

        # Deduct from Inventory if present
        inventory = Inventory.query.filter_by(product_id=product.id).first()
        if inventory:
            inventory.stock -= item["quantity"]
            inventory.updated_at = datetime.utcnow()

    # Clear user's cart
    Cart.query.filter_by(user_id=user_id).delete()

    db.session.commit()

    return jsonify({
        "message": "Order placed successfully",
        "order_id": new_order.id,
        "status": new_order.status,
        "total_price": total_price
    }), 201


# {
#   "address_id": 2,
#   "payment_mode": "cod"
# }

# curl --location 'http://127.0.0.1:5000/place' \
# --data '{
#   "address_id": 2,
#   "payment_mode": "cod"
# }'



# note:- 
# Make sure:

# Address exists and belongs to user

# Cart has items

# Enough stock exists












@order_bp.route("/userorder", methods=["GET"])
@jwt_required()
def get_user_orders():
    user_id = get_jwt_identity()
    orders = Order.query.filter_by(user_id=user_id).order_by(Order.created_at.desc()).all()
    return jsonify([{
        "order_id": order.id,
        "total_price": order.total_price,
        "status": order.status,
        "created_at": order.created_at.isoformat()
    } for order in orders]), 200

# http://127.0.0.1:5000/userorder

# curl --location 'http://127.0.0.1:5000/userorder' \
# --header 'Authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJmcmVzaCI6ZmFsc2UsImlhdCI6MTc0NDgxNDY1OCwianRpIjoiN2NmNTNhMWUtYzMzOC00NzFjLWJiYjYtYTg3YWVhNDY4NTMzIiwidHlwZSI6ImFjY2VzcyIsInN1YiI6IjciLCJuYmYiOjE3NDQ4MTQ2NTgsImNzcmYiOiIyYWFkZGM4YS04YjNmLTRkM2UtOTAxMS1hOTliMTMxYTgwOTgiLCJleHAiOjE3NDQ5MDEwNTh9.PfF2OSWLlTHkb3wNHi1KiF3lx0TB2yr1J55Wtv_bZ5s'


# [
#     {
#         "created_at": "2025-04-16T14:49:03",
#         "order_id": 3,
#         "status": "Pending",
#         "total_price": 1180.0
#     },
#     {
#         "created_at": "2025-04-16T14:45:33",
#         "order_id": 2,
#         "status": "Pending",
#         "total_price": 735.0
#     }
# ]



@order_bp.route("/order_details/<int:order_id>", methods=["GET"])
@jwt_required()
def get_order_details(order_id):
    user_id = get_jwt_identity()
    order = Order.query.filter_by(id=order_id, user_id=user_id).first()

    if not order:
        return jsonify({"error": "Order not found"}), 404

    items = [{
        "product_id": item.product_id,
        "product_name": item.product.name,
        "quantity": item.quantity,
        "unit_price": item.price_at_order_time
    } for item in order.order_items]

    return jsonify({
        "order_id": order.id,
        "total_price": order.total_price,
        "status": order.status,
        "created_at": order.created_at.isoformat(),
        "items": items
    }), 200

# http://127.0.0.1:5000/order_details/2

# curl --location 'http://127.0.0.1:5000/order_details/2' \
# --header 'Authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJmcmVzaCI6ZmFsc2UsImlhdCI6MTc0NDg3OTczNSwianRpIjoiOWU4Y2I4ZDQtYzE2Mi00YzJjLWJmOWQtZWNjMzM2ZDIzYjQ2IiwidHlwZSI6ImFjY2VzcyIsInN1YiI6IjciLCJuYmYiOjE3NDQ4Nzk3MzUsImNzcmYiOiJhMGRiNmQxMy00ODRiLTQ1ZTMtYTc2My04NDJhMDQ4NTNmZmYiLCJleHAiOjE3NDQ5NjYxMzV9.12gKQbZuEmTmDZAE18JDW3AfX8LsZDyZY5IOpg00jFw'



@order_bp.route("/cancel/<int:order_id>", methods=["DELETE"])
@jwt_required()
def cancel_order(order_id):
    user_id = get_jwt_identity()
    order = Order.query.filter_by(id=order_id, user_id=user_id).first()

    if not order:
        return jsonify({"error": "Order not found"}), 404

    if order.status != "Pending":
        return jsonify({"error": "Only pending orders can be canceled"}), 400

    order.status = "Cancelled"
    db.session.commit()

    return jsonify({"message": "Order cancelled successfully"}), 200

# http://127.0.0.1:5000/order/cancel/1

# curl --location --request DELETE 'http://127.0.0.1:5000/order/cancel/1' \
# --header 'Authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJmcmVzaCI6ZmFsc2UsImlhdCI6MTc0NDg3OTczNSwianRpIjoiOWU4Y2I4ZDQtYzE2Mi00YzJjLWJmOWQtZWNjMzM2ZDIzYjQ2IiwidHlwZSI6ImFjY2VzcyIsInN1YiI6IjciLCJuYmYiOjE3NDQ4Nzk3MzUsImNzcmYiOiJhMGRiNmQxMy00ODRiLTQ1ZTMtYTc2My04NDJhMDQ4NTNmZmYiLCJleHAiOjE3NDQ5NjYxMzV9.12gKQbZuEmTmDZAE18JDW3AfX8LsZDyZY5IOpg00jFw'


@order_bp.route("/track/<int:order_id>", methods=["GET"])
@jwt_required()
def track_order_status(order_id):
    user_id = get_jwt_identity()
    order = Order.query.filter_by(id=order_id, user_id=user_id).first()

    if not order:
        return jsonify({"error": "Order not found"}), 404

    return jsonify({"order_id": order.id, "status": order.status}), 200


# http://127.0.0.1:5000/track/2

# curl --location 'http://127.0.0.1:5000/track/2' \
# --header 'Authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJmcmVzaCI6ZmFsc2UsImlhdCI6MTc0NDg3OTczNSwianRpIjoiOWU4Y2I4ZDQtYzE2Mi00YzJjLWJmOWQtZWNjMzM2ZDIzYjQ2IiwidHlwZSI6ImFjY2VzcyIsInN1YiI6IjciLCJuYmYiOjE3NDQ4Nzk3MzUsImNzcmYiOiJhMGRiNmQxMy00ODRiLTQ1ZTMtYTc2My04NDJhMDQ4NTNmZmYiLCJleHAiOjE3NDQ5NjYxMzV9.12gKQbZuEmTmDZAE18JDW3AfX8LsZDyZY5IOpg00jFw'




@order_bp.route("/return/<int:order_id>", methods=["POST"])
@jwt_required()
def return_order(order_id):
    user_id = get_jwt_identity()
    order = Order.query.filter_by(id=order_id, user_id=user_id).first()

    if not order:
        return jsonify({"error": "Order not found"}), 404

    if order.status != "Delivered":
        return jsonify({"error": "Only delivered orders can be returned"}), 400

    order.status = "Returned"
    db.session.commit()

    return jsonify({"message": "Order returned successfully"}), 200






@order_bp.route("/get_all_orders", methods=["GET"])
@jwt_required()
def get_all_orders():
    user_id = get_jwt_identity()
    user = User.query.get(user_id)

    if user.role != "admin":
        return jsonify({"error": "Unauthorized"}), 403

    orders = Order.query.order_by(Order.created_at.desc()).all()
    return jsonify([{
        "order_id": order.id,
        "user": order.user.name,
        "total_price": order.total_price,
        "status": order.status,
        "created_at": order.created_at.isoformat()
    } for order in orders]), 200


# http://127.0.0.1:5000/get_all_orders

# curl --location 'http://127.0.0.1:5000/get_all_orders' \
# --header 'Authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJmcmVzaCI6ZmFsc2UsImlhdCI6MTc0NDg3MzczMSwianRpIjoiYzA1NTRkYWYtZDM1OS00OTM4LWJiYzMtMWM4MzFkOTZiNjNiIiwidHlwZSI6ImFjY2VzcyIsInN1YiI6IjEwIiwibmJmIjoxNzQ0ODczNzMxLCJjc3JmIjoiNjdmNDY0NWItZDJmMy00YWQzLTljNTYtOTVmMDVmZDlmYTFiIiwiZXhwIjoxNzQ0OTYwMTMxfQ.ocuYi2Hi7rt39SN0sRTkPb3VqHeT7xWfthC3ApH9Flc'



@order_bp.route("/update_status/<int:order_id>", methods=["PUT"])
@jwt_required()
def update_order_status(order_id):
    user_id = get_jwt_identity()
    user = User.query.get(user_id)

    if user.role != "admin":
        return jsonify({"error": "Unauthorized"}), 403

    order = Order.query.get(order_id)
    if not order:
        return jsonify({"error": "Order not found"}), 404

    data = request.get_json()
    new_status = data.get("status")

    valid_statuses = ["Pending", "Processing", "Out_for_delivery", "Delivered", "Cancelled", "Returned"]

    if new_status not in valid_statuses:
        return jsonify({"error": f"Invalid status '{new_status}'"}), 400

    order.status = new_status
    db.session.commit()

    return jsonify({"message": f"Order status updated to '{new_status}'"}), 200































# # Assign Delivery Boy to Order (Admin Only)
# @order_bp.route("/assign_delivery_boy/<int:order_id>", methods=["PUT"])
# @jwt_required()
# def assign_delivery_boy(order_id):
#     user_id = get_jwt_identity()
#     admin = User.query.get(user_id)

#     if admin.role != "admin":
#         return jsonify({"error": "Unauthorized"}), 403

#     order = Order.query.get(order_id)
#     if not order:
#         return jsonify({"error": "Order not found"}), 404

#     data = request.get_json()
#     delivery_boy_id = data.get("delivery_boy_id")

#     if not delivery_boy_id:
#         return jsonify({"error": "Delivery boy ID is required"}), 400

#     delivery_boy = User.query.get(delivery_boy_id)
#     if not delivery_boy or delivery_boy.role != "delivery_boy":
#         return jsonify({"error": "Invalid delivery boy"}), 400

#     order.delivery_boy_id = delivery_boy_id
#     db.session.commit()

#     return jsonify({
#         "message": f"Delivery boy '{delivery_boy.name}' assigned to order {order.id}",
#         "order": order.to_dict()
#     }), 200

